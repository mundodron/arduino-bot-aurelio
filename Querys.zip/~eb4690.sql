select * from GVT_FEBRABAN_BILL_INVOICE 


select * from customer_id_equip_map