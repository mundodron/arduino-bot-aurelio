select * from g0023421sql.GVT_VAL_PLANO

grant select on g0023421sql.GVT_VAL_PLANO_DADOS to public


select * from g0023421sql.GVT_VAL_PLANO_DADOS