select * from cmf_balance where bill_ref_no = 109370902

select * from customer_id_acct_map where external_id = '999989574466'