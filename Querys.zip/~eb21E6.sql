select * from adj

select * from gvt_bankslip
