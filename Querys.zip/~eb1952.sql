select * from customer_id_acct_map where external_id = '999989025404'

select * from Local_address where ADDRESS_ID = 1349899004