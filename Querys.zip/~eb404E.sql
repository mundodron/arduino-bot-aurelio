ARBOR.sql_get_seq_num('PAYMENT_PROFILE');

select profile_id, account_no, pay_method from PAYMENT_PROFILE

SELECT COUNT(*)
          FROM SEQ_NUM 
          
select * from d_stmt_count