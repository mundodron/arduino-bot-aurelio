select * from all_tables where table_name like '%FEBRABAN%'


select * from GVT_FEBRABAN_BILL_INVOICE where account_no in (111476206) 

select * from cmf_balance where bill_ref_no = 111476206