select * from lbx_error where bill_ref_no = 134390740;


