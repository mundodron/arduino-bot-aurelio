select USER, REMARK from CMF where no_bill = 1


select * from GVT_CONTROLE_NO_BILL


       SELECT EXTERNAL_ID,:new.no_bill,SYSDATE,0
       FROM CUSTOMER_ID_ACCT_MAP EIAM
       WHERE EIAM.ACCOUNT_NO = :OLD.ACCOUNT_NO
       AND   EIAM.EXTERNAL_ID_TYPE=1;
       
       
       select * from BORGVT_CORPORATE.
       
       select * from GVT_CONTROLE_NOBILL
       
select count(*),
       REMARK 
  from CMF
 where no_bill = 1
 group by (REMARK)
 order by 1 desc


select count(*), 
       CHG_WHO 
  from CMF
 where no_bill = 1
 group by (CHG_WHO)
 order by 1 desc
 
 
 select * from all_tables where table_name like '%CMF%' 
 
 select quem, quando  from GVT_LOG_CMF
 
 select * from GVT_CONTROLE_NOBILL where account_no = 4180250
 
  R_ARBOR_RO
  
select * from arborgvt_billing.GVT_CONTROLE_NO_BILL
  
select * from GVT_CONTROLE_NOBILL order by 1 desc
  
select * from gvt_no_bill_audit
  
select * from gvt_log_cmf where account_no = 1127907
  
select * from PROCESS_SCHED 

select * from cmf

select * from CDR_DATA_WORK