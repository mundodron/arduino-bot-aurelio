select * from cmf_balance where bill_ref_no = 145414262

select * from cmf_balance_detail where bill_ref_no = 145414262

select * from bmf where account_no = 7662073

select * from bill_invoice where bill_ref_no = 145414262

select * from bmf_distribution where bill_ref_no = 145414262

147900002


select * from bmf where TRACKING_ID = 11754189