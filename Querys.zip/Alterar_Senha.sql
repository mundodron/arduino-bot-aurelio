alter user user_name identified by new_password replace old_password

alter user P9904637SQL identified by SQL63219 replace SQL63218