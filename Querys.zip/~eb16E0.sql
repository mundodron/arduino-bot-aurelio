select * from GVT_LOG_DET_FATURAMENTO_CD order by dt_inclusao desc

select * from dual