select * from cmf_balance where account_no in (3869396,8348848,8396108)

select * from cdr_data where account_no in (3869396,8348848,8396108)

