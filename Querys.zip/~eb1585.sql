select * from RETORNO_CORROMPIDAS_ABNC where bill_ref_no = 137807444


BILL_REF_NO,PROBLEMA,FILE_NAME,DATA
137807444,Nota Fiscal invalida
,ImagensCorrompidas_Remessa_42617_Production_Sme_EXT_20130320.txt,21/03/2013 21:27:50
