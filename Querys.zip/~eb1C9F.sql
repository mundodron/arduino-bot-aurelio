delete from lbx_error where bill_ref_no in (141991448,140473851);

commit;