select * from bill_invoice where bill_ref_no = '214209347'

