select * from bill_invoice_detail where bill_ref_no = 186128327

select * from descriptions where description_code = 16619

select * from GVT_DURATION_USG_VARIABLE where type_id_usg = 619

select * from GVT_DURATION_USG_VARIABLE order by 1 asc

select * from 