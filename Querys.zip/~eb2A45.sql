               select * from cmf_balance
                        where account_no = 3861883
                        and bill_ref_no = 97099284
                        
                        
                        -123
                        
                