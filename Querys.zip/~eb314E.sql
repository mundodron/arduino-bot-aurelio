select * from gvt_cease_account where serv_inst='MGA-104LZ8I4-003-104LZ8IF';
