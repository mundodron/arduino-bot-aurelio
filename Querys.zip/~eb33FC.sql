select * from gvt_febraban_ponta_B_arbor where EMF_EXT_ID not in (select EMF_EXT_ID from gvt_febraban_ponta_B_arbor_bk)

select * from gvt_febraban_ponta_b_arbor where emf_ext_id = 'CTA-3015SNRP7-9698'
