select * from grc_servicos_prestados

select * from gvt_historico_cdrs_ajustados where bill_ref_no in('225340144','218682976','212025353','205578963');


select * from gvt_historico_cdrs_ajustados where bill_ref_no in('225340144','218682976','212025353','205578963');


select * from ARBORGVT_BILLING.GVT_AVULSO_FATURACD

