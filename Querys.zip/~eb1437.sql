select        
curranal,
request,
          --(SUBSTR (descript, INSTR (descript, 'Rpon: ') + 6, 8)) AS rPON,
     -- (SUBSTR (descript, INSTR (descript, 'Documento:') + 11, 14)) AS documento,
--       (SUBSTR (descript, INSTR (descript, 'Conta:') + 7, 12)) AS Conta ,
    --  (SUBSTR (descript, INSTR (descript, 'Cobran�a: ') + 10, 12)) AS Conta,
  --    (SUBSTR (descript, INSTR (descript, 'atura: ') + 7, 10)) AS Fatura1,
--       (SUBSTR (descript, INSTR (descript, 'atura ') + 7, 10)) AS Fatura2,
      (SUBSTR (descript, INSTR (descript, 'no Arbor:') + 10,10)) AS Fatura,
      descript    
from request
where closed = 0 
and curranal like '%Evelise Santos%'

where curranal = 'IT Suporte Arrecada��o'
and closed = 0