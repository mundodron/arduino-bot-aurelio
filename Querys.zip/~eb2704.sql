select * from gvt_rajadas_bill where external_id = '999992783911'

select * from bmf where account_no = 4244287 and orig_bill_ref_no = 97757961

select * 
  from bmf b1
 where trunc(B1.trans_date) > to_date ('01/12/2011','dd/mm/yyyy')
   and trunc(B1.trans_date) <= to_date ('01/12/2011','dd/mm/yyyy') 

select * from customer_id_acct_map where external_id = '999992783911'

select * from bmf where account_no = 1623044 and bill_ref_no = 97325047
         