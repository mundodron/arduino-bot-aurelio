select * from customer_id_acct_map where external_id = '999990677049'

select * from bmf where account_no = 2219636

select * from cmf_balance where account_no = 2219636

select *
   from payment_trans
  where bill_ref_no in (106387795);