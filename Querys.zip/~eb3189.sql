select * from GVT_DACC_GERENCIA_MET_PGTO where external_id = 999982238132

select 