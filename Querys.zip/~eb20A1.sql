select * from bank_seqs --interno
where bank_id = 001