select * from cmf where account_no in (6481004,7423616,3869396)

