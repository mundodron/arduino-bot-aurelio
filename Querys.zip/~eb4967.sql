select * from all_tables where table_name like '%DACC%'

select * from GVT_DACC_GERENCIA_FILA_EVENTOS where external_id = '999994447920' 

select * from GVT_DACC_HIST_MET_PGTO where external_id = '999994447920' 


