delete from lbx_error where bill_ref_no in (122691918,120024354);

commit;


