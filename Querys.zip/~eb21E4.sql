select * from customer_id_acct_map where account_no = 6647148
