select * from gvt_febraban_accounts where external_id in (999980501190,899999165905,899999221244,999999234617,999979741087)

select * from gvt_febraban_bill_invoice where bill_ref_no in (259875908,260043760,260879528,260268050,259880198)

select * from gvt_fbb_bill_invoice where bill_ref_no in (259875908,260043760,260879528,260268050,259880198)

select * from gvt_fbb_bill_invoice 

select * from customer_id_acct_map where external_id in ('999979741087','899999165905')