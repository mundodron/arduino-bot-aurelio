select * from GVT_RELATORIO_CIRCUITO_DADOS where id_circuito = 293973

select Designador, count(1) from GVT_RELATORIO_CIRCUITO_DADOS where DATE_GERACAO = '20/FEB/2012' group by Designador

select count(*) from GVT_RELATORIO_CIRCUITO_DADOS where DATE_GERACAO >= '20/FEB/2012'


    
    