select * from cmf_balance where bill_ref_no in (142148136,141759364)

select * from GVT_FEBRABAN_BILL_INVOICE where bill_ref_no in (142148136,141759364)

select * from GVT_FBB_BILL_INVOICE where bill_ref_no in (142148136,141759364)

select * from gvt_febraban_accounts where account_no in (4646486,2633494)

