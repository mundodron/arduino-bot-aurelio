delete from lbx_error where bill_ref_no = 76648445;

commit;