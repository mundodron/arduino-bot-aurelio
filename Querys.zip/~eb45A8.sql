select * from cmf_balance where account_no = 145819102

select * from bill_invoice where account_no = 145819102

select * from cmf_balance where bill_ref_no in (152714502)


