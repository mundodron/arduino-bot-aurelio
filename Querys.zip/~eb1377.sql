select * from all_tables where table_name like '%RETORNO%' 


select bill_ref_no ||',' from GVT_NRC_INVALIDA where valor is not null