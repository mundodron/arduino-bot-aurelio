select lote, tcoe from grc_servicos_prestados where DATA_INSERCAO > sysdate -6

