select *
                              from cmf_balance
                             where account_no = 3655602
                               and bill_ref_no = 113233911


select * from G0023421SQL.GVT_ERRO_SANTANDER

select * from 