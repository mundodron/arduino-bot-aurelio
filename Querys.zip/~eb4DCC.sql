select * from GVT_BILL_INVOICE_TOTAL order by 1 desc

select * from gvt_bill_invoice_total where bill_ref_no = 130475958

select * from GVT_BILL_INVOICE_TOTAL

select * from gvt_bill_invoice_total where bill_ref_no = 165269902
                                                     
-- nota fiscal
select * from GVT_BILL_INVOICE_NFST

-- valor total da fatura
select * from GVT_BILL_INVOICE_TOTAL_TAX

select * from gvt_febraban_ponta_b_arbor where emf_ext_id = 'SPO-30161NFIL-032'
