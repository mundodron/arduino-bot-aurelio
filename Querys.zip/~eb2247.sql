select * from COBILLING.GVT_CONTROLE_CAD_CLIENTE order by sequencia desc

select * from GVT_CADASTRO_CLIENTE where linha_ddd = 43 and linha_telefone = 33293720 -- 40625108 --33271744 

select * from GVT_CAD_CLIENTE_IND 

select * from GVT_CAD_CLIENTE_TEMP where telefone = '4140625108'

-- 4333271744

select 7141582 - 4129657 from dual

select * from customer_id_acct_map where external_id = '999994262904'

select * from bmf where account_no = 1229677 and bill_ref_no = 0110578995

select * from cmf_balance where account_no = 1229677 and bill_ref_no = 0110578995

select * from cmf where account_no = 1229677

select * from GVT_CAD_CLIENTE

select * from 