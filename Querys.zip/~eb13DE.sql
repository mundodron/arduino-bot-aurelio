select * from customer_id_acct_map where account_no = 8551415

select * from customer_id_acct_map where external_id = '899998500563'

select * from bill_invoice where account_no = 8551415

select * from cmf_balance where bill_ref_no = 196711949

select * from cmf where account_no = 8551415

select rowid, a.* from cmf a where account_no = 8551415