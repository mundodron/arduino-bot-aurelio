select * from GVT_DETALHAMENTO_CICLO


select * from customer_id_acct_map where external_id = '999979656398'

select * from bill_invoice where account_no = 7564090 order by 2 desc

select * from all_tables where table_name like '%ADDRESS%'

select * from LOCAL_ADDRESS where address_id = 4825712004

select * from SERVICE_ADDRESS_ASSOC where address_id = 4825712004



select * from cmf where account_no = 7564090

select * from SERVICE_CENTERS

