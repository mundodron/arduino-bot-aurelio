select * from bill_invoice_detail where bill_ref_no = 161213913
