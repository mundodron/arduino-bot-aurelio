-- Descri��o: Por favor, verificar por que as faturas 143494431,142815730,142815531,141426118,141430134,
              tem minutos faturados e n�o est�o na tabela GVT_HISTORY_EIF.


select * from cmf_balance where bill_ref_no in (143494431,142815730,142815531,141426118,141430134)

select * from GVT_HISTORY_EIF where bill_ref_no in (143494431,142815730,142815531,141426118,141430134)
 