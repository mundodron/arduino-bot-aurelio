 SELECT *
   FROM sin_seq_no
  WHERE bill_ref_no  in (163334545, 162204541, 162033129)
    AND bill_ref_resets = 0
    AND open_item_id = 0 