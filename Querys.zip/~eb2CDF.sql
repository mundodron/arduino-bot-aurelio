select * from lbx_error where bill_ref_no = (102172451)

delete from lbx_error where bill_ref_no = (102172451);

commit;