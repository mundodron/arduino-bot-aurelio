select * from gvt_febraban_ponta_b_arbor order by 4 desc

select * from BQ_FEBRABAN_PONTA

select * from all_tables where table_name like '%FEBRABAN%' 