select * from bill_invoice where bill_ref_no = 25254597


ARBORGVT_BILLING.PKG_VAL_CONTAS_PROFORMA
