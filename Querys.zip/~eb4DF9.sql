select * from all_tables where table_name like '%FEBRABAN%' 

select * from GVT_FEBRABAN_PONTA_B_ARBOR where CMF_EXT_ID = '999983795899'