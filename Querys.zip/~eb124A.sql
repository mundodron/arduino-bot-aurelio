select * from customer_id_acct_map where external_id = '999984360097'
