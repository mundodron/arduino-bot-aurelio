select * from g0023421sql.gvt_cob

update gvt_cob set arquivo = 'TCOF.T211167.S01.D301111.H0911.K231110' where arquivo is null



