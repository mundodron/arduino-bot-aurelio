select * from cmf_balance where bill_ref_no in (146342655)

select * from all_tables where table_name like '%DACC%' 

select * from GVT_DACC_GERENCIA_FILA_EVENTOS where external_id = 999988000119 --999995679714

select * from GVT_DACC_GERENCIA_MET_PGTO where external_id = 999995679714

select * from 