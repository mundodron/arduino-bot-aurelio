select * from gvt_product_velocity where tracking_id=18293028 and tracking_id_serv=3;

select * from gvt_product_velocity where tracking_id=15035320 and tracking_id_serv=3;

select * from gvt_product_velocity where tracking_id=20678751 and tracking_id_serv=3;

select * from gvt_product_velocity where tracking_id=15549537 and tracking_id_serv=3;

select * from gvt_product_velocity where tracking_id=18293027 and tracking_id_serv=3;

select * from gvt_product_velocity where tracking_id=20669008 and tracking_id_serv=3;

select * from gvt_product_velocity where tracking_id=15035443 and tracking_id_serv=3;

select * from gvt_product_velocity where tracking_id=15549543 and tracking_id_serv=3;


SELECT *
FROM   flashback_transaction_query