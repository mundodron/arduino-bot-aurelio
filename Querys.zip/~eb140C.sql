select * from customer_id_acct_map where external_id = '899998502871'

select * from customer_id_acct_map where external_id = '899998500563'