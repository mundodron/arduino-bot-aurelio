select * from cmf_balance where bill_ref_no = 212620062

select * from bill_invoice

Select * from bill_invoice_detail where bill_ref_no=212620062;