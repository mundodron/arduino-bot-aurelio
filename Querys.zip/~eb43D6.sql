select * from all_tables where table_name like '%BMF%' 

select * from BANK_NAMES where bank_code = 422

select * from BMF_TRANS_DESCR where BMF_TRANS_CATEGORY = 422

select * from LBX_PAYMENT_TYPES where source_id = 422

select * from lbx_payment_types where bmf_trans_type = -151

select * from BMF_TRANS_DESCR where BMF_TRANS_TYPE = -291

select * from DESCRIPTION_CODE

select * from cmf_balance where bill_ref_no in (102628858,102396367,100750898,102836476,101792734,102743871,102829307,101882355,101793157,101807731,102946070,101926733,101794713,101915533,101916216,102712677,102616107)




