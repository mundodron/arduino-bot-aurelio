select * from bill_invoice_detail where bill_ref_no in (173798302,173799303,173799304,173799305,173799306,173799302)

select account_no from bill_invoice where  bill_ref_no in (173798302,173799303,173799304,173799305,173799306,173799302)

select * from bill_invoice_detail where bill_ref_no in (173798302,173799303,173799304,173799305,173799306,173799302)
