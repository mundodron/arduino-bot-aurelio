delete from lbx_error where bill_ref_no in (133462412,133667815)

select * from lbx_error