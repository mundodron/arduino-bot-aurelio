select * from cmf_balance where bill_ref_no = 135351122--142907225

select * from CMF_BALANCE_DETAIL where bill_ref_no = 135351122;

select * from SIN_SEQ_NO where bill_ref_no = 135351122;

select * from BILL_INVOICE where bill_ref_no = 135351122


 

