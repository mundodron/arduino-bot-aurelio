select * from all_tables where table_name like '%FEBRABAN%'

