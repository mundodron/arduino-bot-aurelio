select * from customer_id_equip_map where external_id = '4132428665'

select * from service where subscr_no = 6272706 

select * from cmf where account_no = 2987706

select * from cmf_balance where account_no = 2987706

