select * from GVT_BILL_INVOICE_TOTAL

select * from CMF_BALANCE_DETAIL
                                                     
select * from GVT_BILL_INVOICE_NFST

select * from GVT_BILL_INVOICE_TOTAL_TAX

select * from GVT_HISTORY_EIF



select * from GVT_BILL_INVOICE_TOTAL order by 1 desc

select * from gvt_bill_invoice_total where bill_ref_no = 130475958

select * from gvt_bill_invoice_total where bill_ref_no = 165269902


select * from gvt_febraban_ponta_b_arbor where emf_ext_id = 'SPO-30161NFIL-032'
