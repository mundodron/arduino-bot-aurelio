select source_id, max(SEQUENTIAL_NO) from file_seqs 
group by source_id


