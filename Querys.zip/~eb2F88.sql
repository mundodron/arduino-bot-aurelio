select * from gvt_rajadas_bill where status = 778

select * from customer_id_acct_map where external_id = '999985734913'

select * from bill_invoice