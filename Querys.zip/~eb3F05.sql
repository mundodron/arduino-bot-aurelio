select * from cmf_balance where bill_ref_no = 145414262

select * from CMF_BALANCE_DETAIL where bill_ref_no = 142907225 and OPEN_ITEM_ID =1

select * from SIN_SEQ_NO where bill_ref_no = 142907225 and OPEN_ITEM_ID =0

select * from BILL_INVOICE where bill_ref_no = 142907225

select * from cmf_balance_detail where bill_ref_no = 142907225 and OPEN_ITEM_ID =1

select * from sin_seq_no where bill_ref_no = 142907225

select MKT_CODE from cmf where account_no = 6647148

select * from gvt_sinseqno_series where mkt_code= '23' and open_item_id = '0';

