select * from all_tables where table_name like '%_CD%'

select * from GVT_LOG_DET_FATURAMENTO_CD order by dt_inclusao desc

select * from ARBORGVT_BILLING.GVT_DET_FATURAMENTO_CD

alter user G0023421SQL identified by SQL23421