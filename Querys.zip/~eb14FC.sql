                select * from GVT_SUMMARY_ZERO_ALLOWED where component_id in (29649,29897)
                
                select * from bill_invoice_detail where bill_ref_no = 161213913 and component_id in (29649,29897)