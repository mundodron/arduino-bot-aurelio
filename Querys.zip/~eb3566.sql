select * from gvt_ctrl_fluxo_caixa where trunc(data_movimento) = to_date ('28/05/2012','dd/mm/yyyy')

select * from gvt_ctrl_fluxo_caixa where external_id = 999984665057

select response_code from payment_trans

select * from eft_response_code_values  