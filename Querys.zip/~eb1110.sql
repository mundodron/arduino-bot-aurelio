select * from customer_id_acct_map where external_id = '999984360097'

select account_no, orig_bill_ref_no, bmf_trans_type, trans_date, post_date, gl_amount, chg_date,  trans_submitter from bmf where account_no = 4058712
