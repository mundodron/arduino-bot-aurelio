select max(arquivo) from gvt_controle_debito group by arquivo

select * from gvt_controle_debito 

