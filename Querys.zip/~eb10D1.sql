update payment_profile set PAY_METHOD = 3 where account_no = 1409494 and PROFILE_ID = 1409494500;

commit;